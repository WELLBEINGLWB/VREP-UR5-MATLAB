% Copyright 2006-2017 Coppelia Robotics GmbH. All rights reserved. 
% marc@coppeliarobotics.com
% www.coppeliarobotics.com
% 
% -------------------------------------------------------------------
% THIS FILE IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
% WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
% AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
% DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
% MISUSING THIS SOFTWARE.
% 
% You are free to use/modify/distribute this file for whatever purpose!
% -------------------------------------------------------------------
%
% This file was automatically created for V-REP release V3.4.0 rev. 1 on April 5th 2017

% Make sure to have the server side running in V-REP: 
% in a child script of a V-REP scene, add following command
% to be executed just once, at simulation start:
%
% simExtRemoteApiStart(19999)
%
% then start simulation, and run this program.
%
% IMPORTANT: for each successful call to simxStart, there
% should be a corresponding call to simxFinish at the end!

disp('Program started');
vrep = remApi('remoteApi');
vrep.simxFinish(-1);
clientID = vrep.simxStart('127.0.0.1', 19999, true, true, 5000, 5);

theta = [0, -pi/6, -pi/3, -pi/6, -pi/3, -pi/2];
totalTime = 10.0;
simuTime = 0.0;
timeStep = 0.01;

if (clientID>-1) 
    disp('Connected to remote API server');
    while (vrep.simxGetConnectionId(clientID) ~= -1 && simuTime <= totalTime)        
        % Set robot joint positions
        [returnCode, ~, ~, ~, ~] = vrep.simxCallScriptFunction(clientID, 'UR5', vrep.sim_scripttype_childscript, 'setJointPos_function', [], theta, '', [], vrep.simx_opmode_blocking);
        
        theta(1) = pi/6*sin(2*pi*simuTime/5);
        
        disp(simuTime)
        simuTime = simuTime + timeStep;
    end 
    % Before closing the connection to V-REP, make sure that the last command sent out had time to arrive. You can guarantee this with (for example):
    vrep.simxGetPingTime(clientID);
    % Now close the connection to V-REP:
    vrep.simxFinish(clientID);  
else
    disp('Failed connecting to remote API server');
end
vrep.delete(); % call the destructor!

disp('Program ended');
